import Vue from "vue";

let EventsBus = new Vue();

export default EventsBus;